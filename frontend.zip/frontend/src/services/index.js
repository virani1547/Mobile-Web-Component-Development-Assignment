import api from './api';

// Auth Services
export const authService = {
  login: (email, password) => api.post('/auth/login', { email, password }),
  register: (userData) => api.post('/auth/register', userData),
  logout: () => api.post('/auth/logout'),
  getCurrentUser: () => api.get('/auth/me'),
};

// Course Services
export const courseService = {
  getAllCourses: () => api.get('/courses'),
  getCourse: (courseId) => api.get(`/courses/${courseId}`),
  createCourse: (data) => api.post('/courses', data),
  enrollStudent: (courseId, studentId) => api.post(`/courses/${courseId}/enroll`, { student_id: studentId }),
};

// Assignment Services
export const assignmentService = {
  getAssignment: (assignmentId) => api.get(`/assignments/${assignmentId}`),
  getCourseAssignments: (courseId) => api.get(`/assignments/course/${courseId}`),
  createAssignment: (data) => api.post('/assignments', data),
};

// Submission Services
export const submissionService = {
  submitAssignment: (data) => api.post('/submissions', data),
  getSubmission: (submissionId) => api.get(`/submissions/${submissionId}`),
  getAssignmentSubmissions: (assignmentId) => api.get(`/submissions/assignment/${assignmentId}`),
};

// Grade Services
export const gradeService = {
  gradeSubmission: (data) => api.post('/grades', data),
  getStudentGrades: (studentId) => api.get(`/grades/student/${studentId}`),
  getCourseGrades: (courseId) => api.get(`/grades/course/${courseId}`),
};

// Student Services
export const studentService = {
  getStudent: (studentId) => api.get(`/students/${studentId}`),
  updateStudent: (studentId, data) => api.put(`/students/${studentId}`, data),
};
