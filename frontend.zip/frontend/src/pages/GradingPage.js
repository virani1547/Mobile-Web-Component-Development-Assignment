import React, { useState } from 'react';
import { Download, MessageSquare, Send } from 'lucide-react';

export function GradingPage() {
  const [grade, setGrade] = useState('');
  const [feedback, setFeedback] = useState('');

  const submission = {
    id: 1,
    student: 'John Smith',
    assignment: 'Python Assignment 3',
    course: 'Introduction to Python',
    submittedDate: new Date(Date.now() - 2 * 60 * 60 * 1000),
    maxPoints: 50,
    content: 'def fibonacci(n):\n    if n <= 1:\n        return n\n    return fibonacci(n-1) + fibonacci(n-2)',
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="heading-1 mb-2">Grade Submission</h1>
        <p className="text-secondary">{submission.assignment} - {submission.student}</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Submission Preview */}
        <div className="lg:col-span-2 space-y-6">
          {/* Student Info */}
          <div className="card p-6">
            <h2 className="heading-2 mb-4">Submission Details</h2>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-700">Student</span>
                <span className="font-semibold text-gray-900">{submission.student}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-700">Course</span>
                <span className="font-semibold text-gray-900">{submission.course}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-700">Submitted</span>
                <span className="font-semibold text-gray-900">{submission.submittedDate.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Submission Content */}
          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="heading-2">Submitted Work</h2>
              <button className="flex items-center gap-2 btn-ghost">
                <Download size={20} />
                Download
              </button>
            </div>
            <pre className="bg-gray-100 p-4 rounded-lg overflow-x-auto text-sm font-mono">
              {submission.content}
            </pre>
          </div>
        </div>

        {/* Grading Panel */}
        <div className="space-y-6">
          {/* Grade Input */}
          <div className="card p-6">
            <h3 className="heading-3 mb-4">Assign Grade</h3>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Points</label>
              <div className="relative">
                <input
                  type="number"
                  value={grade}
                  onChange={(e) => setGrade(e.target.value)}
                  placeholder="0"
                  max={submission.maxPoints}
                  min="0"
                  className="input-field"
                />
                <span className="absolute right-4 top-3 text-gray-500">/ {submission.maxPoints}</span>
              </div>
            </div>

            {grade && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
                <p className="text-sm text-blue-700 mb-1">Score</p>
                <p className="text-3xl font-bold text-blue-600">{Math.round((parseInt(grade) / submission.maxPoints) * 100)}%</p>
              </div>
            )}
          </div>

          {/* Feedback */}
          <div className="card p-6">
            <h3 className="heading-3 mb-4">Feedback</h3>
            <textarea
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="Write your feedback here..."
              className="w-full h-24 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
          </div>

          {/* Submit Grade */}
          <button className="btn-primary w-full flex items-center justify-center gap-2">
            <Send size={20} />
            Submit Grade
          </button>

          {/* Rubric */}
          <div className="card p-6">
            <h3 className="heading-3 mb-4">Rubric</h3>
            <div className="space-y-3">
              <div className="pb-3 border-b border-gray-200">
                <p className="font-medium text-gray-900">Code Quality</p>
                <p className="text-xs text-secondary mt-1">10 points</p>
              </div>
              <div className="pb-3 border-b border-gray-200">
                <p className="font-medium text-gray-900">Correctness</p>
                <p className="text-xs text-secondary mt-1">20 points</p>
              </div>
              <div>
                <p className="font-medium text-gray-900">Documentation</p>
                <p className="text-xs text-secondary mt-1">20 points</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
