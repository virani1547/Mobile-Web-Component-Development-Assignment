import React, { useState, useEffect } from 'react';
import { BarChart3, Users, FileText, TrendingUp, Plus } from 'lucide-react';

export function InstructorDashboard({ user }) {
  const [courses, setCourses] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulated API call
    setTimeout(() => {
      setCourses([
        {
          id: 1,
          title: 'Introduction to Python',
          code: 'CS101',
          students: 45,
          assignments: 8,
          averageGrade: 82,
        },
        {
          id: 2,
          title: 'Web Development Basics',
          code: 'WEB201',
          students: 32,
          assignments: 6,
          averageGrade: 85,
        },
        {
          id: 3,
          title: 'Advanced Python',
          code: 'CS301',
          students: 28,
          assignments: 10,
          averageGrade: 88,
        },
      ]);

      setSubmissions([
        {
          id: 1,
          studentName: 'John Smith',
          assignment: 'Python Assignment 3',
          course: 'CS101',
          submittedDate: new Date(Date.now() - 1 * 60 * 60 * 1000),
          status: 'pending',
        },
        {
          id: 2,
          studentName: 'Sarah Johnson',
          assignment: 'Website Project',
          course: 'WEB201',
          submittedDate: new Date(Date.now() - 5 * 60 * 60 * 1000),
          status: 'pending',
        },
        {
          id: 3,
          studentName: 'Michael Chen',
          assignment: 'Python OOP',
          course: 'CS301',
          submittedDate: new Date(Date.now() - 12 * 60 * 60 * 1000),
          status: 'pending',
        },
      ]);

      setLoading(false);
    }, 500);
  }, []);

  const formatDate = (date) => {
    const now = new Date();
    const diff = now - date;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    if (hours < 1) {
      const minutes = Math.floor(diff / (1000 * 60));
      return `${minutes} minutes ago`;
    }
    return `${hours} hours ago`;
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="heading-1 mb-2">Welcome back, {user?.name}! 👋</h1>
          <p className="text-secondary">Manage your courses and review student submissions</p>
        </div>
        <button className="btn-primary flex items-center gap-2">
          <Plus size={20} />
          Create Course
        </button>
      </div>

      {/* Overview Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary text-sm mb-1">Total Courses</p>
              <p className="heading-3">3</p>
            </div>
            <BarChart3 className="text-blue-600" size={32} />
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary text-sm mb-1">Total Students</p>
              <p className="heading-3">105</p>
            </div>
            <Users className="text-purple-600" size={32} />
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary text-sm mb-1">Pending Reviews</p>
              <p className="heading-3">3</p>
            </div>
            <FileText className="text-yellow-600" size={32} />
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary text-sm mb-1">Class Average</p>
              <p className="heading-3">85%</p>
            </div>
            <TrendingUp className="text-green-600" size={32} />
          </div>
        </div>
      </div>

      {/* Recent Submissions */}
      <div className="card p-6">
        <h2 className="heading-2 mb-6">Recent Submissions</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Student</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Assignment</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Course</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Submitted</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="5" className="text-center py-4 text-secondary">Loading...</td>
                </tr>
              ) : submissions.length === 0 ? (
                <tr>
                  <td colSpan="5" className="text-center py-4 text-secondary">No submissions</td>
                </tr>
              ) : (
                submissions.map(submission => (
                  <tr key={submission.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4 px-4 font-medium text-gray-900">{submission.studentName}</td>
                    <td className="py-4 px-4 text-gray-700">{submission.assignment}</td>
                    <td className="py-4 px-4 text-secondary">{submission.course}</td>
                    <td className="py-4 px-4 text-secondary text-sm">{formatDate(submission.submittedDate)}</td>
                    <td className="py-4 px-4">
                      <button className="text-blue-600 hover:text-blue-700 font-medium text-sm">
                        Review & Grade
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Course Overview */}
      <div>
        <h2 className="heading-2 mb-6">Your Courses</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {loading ? (
            <p className="text-secondary">Loading...</p>
          ) : (
            courses.map(course => (
              <div key={course.id} className="card p-6 hover:shadow-lg transition">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-xs font-semibold text-blue-600 mb-1">{course.code}</p>
                    <h3 className="heading-3">{course.title}</h3>
                  </div>
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition">
                    <Plus size={20} className="text-gray-600" />
                  </button>
                </div>

                <div className="space-y-3 mb-6">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">
                      <strong>{course.students}</strong> students
                    </span>
                    <span className="text-sm text-secondary">{course.assignments} assignments</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Class Average</span>
                    <span className="text-sm font-semibold text-green-600">{course.averageGrade}%</span>
                  </div>
                </div>

                <button className="w-full btn-secondary text-center">
                  Manage Course
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="card p-6">
        <h2 className="heading-2 mb-6">Quick Actions</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <button className="p-4 border border-blue-600 rounded-lg hover:bg-blue-50 transition text-left">
            <Plus size={24} className="text-blue-600 mb-2" />
            <p className="font-semibold text-gray-900">Create Assignment</p>
            <p className="text-sm text-secondary">Add new assignment to a course</p>
          </button>
          <button className="p-4 border border-blue-600 rounded-lg hover:bg-blue-50 transition text-left">
            <FileText size={24} className="text-blue-600 mb-2" />
            <p className="font-semibold text-gray-900">Review Submissions</p>
            <p className="text-sm text-secondary">Grade pending submissions</p>
          </button>
          <button className="p-4 border border-blue-600 rounded-lg hover:bg-blue-50 transition text-left">
            <BarChart3 size={24} className="text-blue-600 mb-2" />
            <p className="font-semibold text-gray-900">View Analytics</p>
            <p className="text-sm text-secondary">Check class performance</p>
          </button>
        </div>
      </div>
    </div>
  );
}
