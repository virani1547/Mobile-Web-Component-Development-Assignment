import React, { useState } from 'react';
import { Filter, CheckCircle2 } from 'lucide-react';

export function SubmissionsPage() {
  const [filterStatus, setFilterStatus] = useState('pending');

  const submissions = [
    {
      id: 1,
      student: 'John Smith',
      assignment: 'Python Assignment 3',
      course: 'CS101',
      submittedDate: new Date(Date.now() - 1 * 60 * 60 * 1000),
      status: 'pending',
      grade: null,
    },
    {
      id: 2,
      student: 'Sarah Johnson',
      assignment: 'Website Project',
      course: 'WEB201',
      submittedDate: new Date(Date.now() - 5 * 60 * 60 * 1000),
      status: 'pending',
      grade: null,
    },
    {
      id: 3,
      student: 'Michael Chen',
      assignment: 'Python OOP',
      course: 'CS301',
      submittedDate: new Date(Date.now() - 12 * 60 * 60 * 1000),
      status: 'graded',
      grade: 95,
    },
  ];

  const formatDate = (date) => {
    const now = new Date();
    const diff = now - date;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    if (hours < 1) {
      const minutes = Math.floor(diff / (1000 * 60));
      return `${minutes}m ago`;
    }
    return `${hours}h ago`;
  };

  const filtered = submissions.filter(s => s.status === filterStatus);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="heading-1 mb-2">Student Submissions</h1>
        <p className="text-secondary">Review and grade student work</p>
      </div>

      {/* Filter */}
      <div className="card p-6">
        <div className="flex gap-4">
          <button
            onClick={() => setFilterStatus('pending')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              filterStatus === 'pending'
                ? 'bg-yellow-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Pending Review
          </button>
          <button
            onClick={() => setFilterStatus('graded')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              filterStatus === 'graded'
                ? 'bg-green-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Graded
          </button>
        </div>
      </div>

      {/* Submissions Table */}
      <div className="card overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="text-left py-4 px-6 font-semibold text-gray-700">Student</th>
              <th className="text-left py-4 px-6 font-semibold text-gray-700">Assignment</th>
              <th className="text-left py-4 px-6 font-semibold text-gray-700">Course</th>
              <th className="text-left py-4 px-6 font-semibold text-gray-700">Submitted</th>
              <th className="text-left py-4 px-6 font-semibold text-gray-700">Grade</th>
              <th className="text-left py-4 px-6 font-semibold text-gray-700">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((submission, idx) => (
              <tr key={submission.id} className={`border-b border-gray-100 ${idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'} hover:bg-blue-50`}>
                <td className="py-4 px-6 font-medium text-gray-900">{submission.student}</td>
                <td className="py-4 px-6 text-gray-700">{submission.assignment}</td>
                <td className="py-4 px-6 text-secondary">{submission.course}</td>
                <td className="py-4 px-6 text-sm text-secondary">{formatDate(submission.submittedDate)}</td>
                <td className="py-4 px-6">
                  {submission.grade ? (
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="text-green-600" size={20} />
                      <span className="font-semibold text-gray-900">{submission.grade}/100</span>
                    </div>
                  ) : (
                    <span className="text-yellow-600 font-medium">Pending</span>
                  )}
                </td>
                <td className="py-4 px-6">
                  <button className="text-blue-600 hover:text-blue-700 font-medium text-sm">
                    {submission.status === 'pending' ? 'Grade' : 'View'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
