import React, { useState } from 'react';
import { Filter, AlertCircle, CheckCircle2, Clock } from 'lucide-react';

export function AssignmentsPage() {
  const [filterStatus, setFilterStatus] = useState('all');

  const assignments = [
    {
      id: 1,
      title: 'Python Assignment 3',
      course: 'Introduction to Python',
      dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
      status: 'pending',
      submitted: false,
      points: 50,
    },
    {
      id: 2,
      title: 'Website Project',
      course: 'Web Development Basics',
      dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
      status: 'pending',
      submitted: false,
      points: 100,
    },
    {
      id: 3,
      title: 'Quiz: Machine Learning Basics',
      course: 'Data Science 101',
      dueDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      status: 'overdue',
      submitted: false,
      points: 30,
    },
    {
      id: 4,
      title: 'Data Analysis Project',
      course: 'Data Science 101',
      dueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      status: 'submitted',
      submitted: true,
      grade: 92,
      points: 75,
    },
  ];

  const tabs = [
    { id: 'all', label: 'All', count: assignments.length },
    { id: 'pending', label: 'Upcoming', count: assignments.filter(a => a.status === 'pending').length },
    { id: 'overdue', label: 'Overdue', count: assignments.filter(a => a.status === 'overdue').length },
    { id: 'submitted', label: 'Completed', count: assignments.filter(a => a.status === 'submitted').length },
  ];

  const filtered = filterStatus === 'all' ? assignments : assignments.filter(a => a.status === filterStatus);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="heading-1 mb-2">Assignments</h1>
        <p className="text-secondary">View and submit your assignments</p>
      </div>

      {/* Filter Tabs */}
      <div className="card">
        <div className="flex overflow-x-auto border-b border-gray-200">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilterStatus(tab.id)}
              className={`px-6 py-4 font-medium border-b-2 transition whitespace-nowrap ${
                filterStatus === tab.id
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-700 border-transparent hover:text-gray-900'
              }`}
            >
              {tab.label} <span className="ml-2 text-gray-500">({tab.count})</span>
            </button>
          ))}
        </div>

        <div className="p-6 space-y-4">
          {filtered.map(assignment => (
            <div key={assignment.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-grow">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="heading-3 flex-grow">{assignment.title}</h3>
                    {assignment.status === 'submitted' && (
                      <CheckCircle2 className="text-green-600" size={20} />
                    )}
                    {assignment.status === 'overdue' && (
                      <AlertCircle className="text-red-600" size={20} />
                    )}
                  </div>
                  <p className="text-sm text-secondary mb-2">{assignment.course}</p>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-gray-600">{assignment.points} points</span>
                    {!assignment.submitted && assignment.status !== 'overdue' && (
                      <span className="text-blue-600">Due: {assignment.dueDate.toLocaleDateString()}</span>
                    )}
                  </div>
                </div>

                <div className="text-right">
                  {assignment.submitted ? (
                    <div>
                      <p className="text-2xl font-bold text-green-600">{assignment.grade}</p>
                      <p className="text-sm text-secondary">Grade</p>
                    </div>
                  ) : (
                    <button className="btn-primary">
                      {assignment.status === 'overdue' ? 'Submit Late' : 'Submit'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
