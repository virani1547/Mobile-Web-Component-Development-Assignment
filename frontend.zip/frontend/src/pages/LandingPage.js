import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, TrendingUp, Users, Globe, Award, Zap } from 'lucide-react';

export function LandingPage() {
  return (
    <div className="bg-base">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <div className="mb-8">
          <h1 className="heading-1 mb-6 text-4xl sm:text-5xl lg:text-6xl font-bold">
            Modern Learning,{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
              Simplified
            </span>
          </h1>
          <p className="text-xl text-secondary max-w-2xl mx-auto mb-8">
            EduLearn is a modern learning management system designed for educators and students to connect, collaborate, and thrive in the digital classroom.
          </p>
        </div>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <Link to="/register" className="btn-primary inline-flex items-center gap-2">
            Get Started <ArrowRight size={20} />
          </Link>
          <Link to="/login" className="btn-secondary inline-flex items-center gap-2">
            Sign In <ArrowRight size={20} />
          </Link>
        </div>

        {/* Hero Image / Illustration */}
        <div className="bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg aspect-video flex items-center justify-center text-gray-400">
          <span>Dashboard Preview</span>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="bg-white py-20 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="heading-2 mb-4">Powerful Features</h2>
            <p className="text-xl text-secondary">Everything you need for successful learning</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Feature 1 */}
            <div className="card p-6">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <BookOpen className="text-blue-600" size={24} />
              </div>
              <h3 className="heading-3 mb-2">Quality Education</h3>
              <p className="text-secondary text-sm">
                Access structured courses with materials, assignments, and resources
              </p>
            </div>

            {/* Feature 2 */}
            <div className="card p-6">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="text-green-600" size={24} />
              </div>
              <h3 className="heading-3 mb-2">Track Progress</h3>
              <p className="text-secondary text-sm">
                Monitor performance with detailed grades and analytics
              </p>
            </div>

            {/* Feature 3 */}
            <div className="card p-6">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Users className="text-purple-600" size={24} />
              </div>
              <h3 className="heading-3 mb-2">Collaborate</h3>
              <p className="text-secondary text-sm">
                Connect with instructors and classmates through discussions
              </p>
            </div>

            {/* Feature 4 */}
            <div className="card p-6">
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mb-4">
                <Globe className="text-amber-600" size={24} />
              </div>
              <h3 className="heading-3 mb-2">Learn Anywhere</h3>
              <p className="text-secondary text-sm">
                Access your courses from any device, anytime, anywhere
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="benefits" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="heading-2 mb-4">Why Choose EduLearn?</h2>
            <p className="text-xl text-secondary">Trusted by educators and students worldwide</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Benefit 1 */}
            <div className="card p-8">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl font-bold mb-4">
                ✓
              </div>
              <h3 className="heading-3 mb-3">User-Friendly Interface</h3>
              <p className="text-secondary">
                Intuitive design that makes learning and teaching effortless for everyone
              </p>
            </div>

            {/* Benefit 2 */}
            <div className="card p-8">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl font-bold mb-4">
                ✓
              </div>
              <h3 className="heading-3 mb-3">Secure & Reliable</h3>
              <p className="text-secondary">
                Enterprise-grade security to protect student data and privacy
              </p>
            </div>

            {/* Benefit 3 */}
            <div className="card p-8">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl font-bold mb-4">
                ✓
              </div>
              <h3 className="heading-3 mb-3">24/7 Support</h3>
              <p className="text-secondary">
                Dedicated support team ready to help you succeed
              </p>
            </div>

            {/* Benefit 4 */}
            <div className="card p-8">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl font-bold mb-4">
                ✓
              </div>
              <h3 className="heading-3 mb-3">Real-time Analytics</h3>
              <p className="text-secondary">
                Get actionable insights into student performance and engagement
              </p>
            </div>

            {/* Benefit 5 */}
            <div className="card p-8">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl font-bold mb-4">
                ✓
              </div>
              <h3 className="heading-3 mb-3">Scalable Solution</h3>
              <p className="text-secondary">
                Grows with your institution from small courses to large programs
              </p>
            </div>

            {/* Benefit 6 */}
            <div className="card p-8">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl font-bold mb-4">
                ✓
              </div>
              <h3 className="heading-3 mb-3">Continuous Innovation</h3>
              <p className="text-secondary">
                Regular updates with new features and improvements
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="bg-white py-20 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="heading-2 mb-4">Testimonials</h2>
            <p className="text-xl text-secondary">What our users are saying</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <div className="card p-8 flex flex-col">
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-yellow-400">★</span>
                ))}
              </div>
              <p className="text-gray-700 mb-6 flex-grow">
                "EduLearn transformed the way I teach. The interface is intuitive, and my students love the organized course structure."
              </p>
              <div>
                <p className="font-semibold text-gray-900">Dr. Sarah Johnson</p>
                <p className="text-sm text-secondary">University Professor</p>
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="card p-8 flex flex-col">
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-yellow-400">★</span>
                ))}
              </div>
              <p className="text-gray-700 mb-6 flex-grow">
                "As a student, I appreciate how easy it is to track my assignments and grades. The platform keeps me organized and motivated."
              </p>
              <div>
                <p className="font-semibold text-gray-900">Michael Chen</p>
                <p className="text-sm text-secondary">Computer Science Student</p>
              </div>
            </div>

            {/* Testimonial 3 */}
            <div className="card p-8 flex flex-col">
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-yellow-400">★</span>
                ))}
              </div>
              <p className="text-gray-700 mb-6 flex-grow">
                "The best LMS platform we've implemented. Excellent support team and the features keep improving with each update."
              </p>
              <div>
                <p className="font-semibold text-gray-900">Emily Rodriguez</p>
                <p className="text-sm text-secondary">Educational Administrator</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-600 py-20 text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6">Ready to Transform Your Learning?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of educators and students already using EduLearn
          </p>
          <Link
            to="/register"
            className="bg-white text-blue-600 px-8 py-3 rounded-lg font-bold inline-flex items-center gap-2 hover:bg-gray-100 transition"
          >
            Get Started Free <ArrowRight size={20} />
          </Link>
        </div>
      </section>
    </div>
  );
}
