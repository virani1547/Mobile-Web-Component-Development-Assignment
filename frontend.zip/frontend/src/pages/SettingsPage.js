import React, { useState } from 'react';
import { Moon, Globe, Bell, Lock } from 'lucide-react';

export function SettingsPage() {
  const [settings, setSettings] = useState({
    theme: 'light',
    language: 'english',
    emailNotifications: true,
    pushNotifications: false,
    dataPrivacy: 'public',
  });

  const handleChange = (key, value) => {
    setSettings(prev => ({
      ...prev,
      [key]: value,
    }));
  };

  return (
    <div className="space-y-8 max-w-2xl">
      <div>
        <h1 className="heading-1 mb-2">Settings</h1>
        <p className="text-secondary">Customize your EduLearn experience</p>
      </div>

      {/* Appearance */}
      <div className="card p-6">
        <div className="flex items-center gap-3 mb-6">
          <Moon className="text-blue-600" size={24} />
          <h2 className="heading-2">Appearance</h2>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">Theme</label>
            <div className="grid grid-cols-3 gap-4">
              {['light', 'dark', 'auto'].map(theme => (
                <label key={theme} className={`p-4 border-2 rounded-lg cursor-pointer transition ${
                  settings.theme === theme
                    ? 'border-blue-600 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}>
                  <input
                    type="radio"
                    name="theme"
                    value={theme}
                    checked={settings.theme === theme}
                    onChange={(e) => handleChange('theme', e.target.value)}
                    className="w-4 h-4"
                  />
                  <span className="ml-2 font-medium capitalize text-gray-700">{theme}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Language & Region */}
      <div className="card p-6">
        <div className="flex items-center gap-3 mb-6">
          <Globe className="text-purple-600" size={24} />
          <h2 className="heading-2">Language & Region</h2>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Language</label>
            <select
              value={settings.language}
              onChange={(e) => handleChange('language', e.target.value)}
              className="input-field"
            >
              <option value="english">English</option>
              <option value="spanish">Spanish</option>
              <option value="french">French</option>
              <option value="german">German</option>
              <option value="chinese">Chinese</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Timezone</label>
            <select className="input-field">
              <option>UTC-8 (Pacific Time)</option>
              <option>UTC-5 (Eastern Time)</option>
              <option>UTC (GMT)</option>
              <option>UTC+1 (Central European)</option>
              <option>UTC+8 (Singapore/Hong Kong)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Notifications */}
      <div className="card p-6">
        <div className="flex items-center gap-3 mb-6">
          <Bell className="text-yellow-600" size={24} />
          <h2 className="heading-2">Notifications</h2>
        </div>

        <div className="space-y-4">
          <label className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div>
              <p className="font-medium text-gray-900">Email Notifications</p>
              <p className="text-sm text-secondary">Receive important updates via email</p>
            </div>
            <input
              type="checkbox"
              checked={settings.emailNotifications}
              onChange={(e) => handleChange('emailNotifications', e.target.checked)}
              className="w-5 h-5 rounded"
            />
          </label>

          <label className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div>
              <p className="font-medium text-gray-900">Push Notifications</p>
              <p className="text-sm text-secondary">Get notifications in your browser</p>
            </div>
            <input
              type="checkbox"
              checked={settings.pushNotifications}
              onChange={(e) => handleChange('pushNotifications', e.target.checked)}
              className="w-5 h-5 rounded"
            />
          </label>
        </div>
      </div>

      {/* Privacy & Security */}
      <div className="card p-6">
        <div className="flex items-center gap-3 mb-6">
          <Lock className="text-red-600" size={24} />
          <h2 className="heading-2">Privacy & Security</h2>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">Profile Visibility</label>
            <div className="space-y-2">
              {['public', 'private', 'instructorsOnly'].map(visibility => (
                <label key={visibility} className="flex items-center">
                  <input
                    type="radio"
                    name="visibility"
                    value={visibility}
                    checked={settings.dataPrivacy === visibility}
                    onChange={(e) => handleChange('dataPrivacy', e.target.value)}
                    className="w-4 h-4"
                  />
                  <span className="ml-2 text-gray-700">
                    {visibility === 'public' && 'Public (visible to all)'}
                    {visibility === 'private' && 'Private (only you)'}
                    {visibility === 'instructorsOnly' && 'Instructors Only'}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div className="border-t border-gray-200 pt-4">
            <button className="btn-secondary">
              View Privacy Policy
            </button>
          </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="card border-red-200 border-2 p-6">
        <h2 className="heading-2 text-red-600 mb-4">Danger Zone</h2>
        <p className="text-gray-700 mb-4">
          These actions are irreversible. Please proceed with caution.
        </p>
        <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition font-medium">
          Delete Account
        </button>
      </div>

      {/* Save Button */}
      <button className="btn-primary w-full md:w-auto">
        Save Settings
      </button>
    </div>
  );
}
