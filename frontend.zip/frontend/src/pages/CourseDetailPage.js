import React, { useState } from 'react';
import { ArrowLeft, BookOpen, Users, Calendar, FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function CourseDetailPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');

  const course = {
    id: 1,
    code: 'CS101',
    title: 'Introduction to Python',
    instructor: 'Dr. Smith',
    banner: 'bg-blue-100',
    description: 'Learn Python programming from scratch. This comprehensive course covers variables, data types, control structures, functions, and object-oriented programming.',
    startDate: '2024-01-15',
    endDate: '2024-05-30',
    students: 45,
    modules: 8,
    syllabus: 'Complete Python fundamentals curriculum designed for beginners.',
  };

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'content', label: 'Content' },
    { id: 'assignments', label: 'Assignments' },
    { id: 'people', label: 'People' },
  ];

  return (
    <div className="space-y-8">
      {/* Breadcrumb */}
      <button
        onClick={() => navigate('/courses')}
        className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
      >
        <ArrowLeft size={20} />
        Back to Courses
      </button>

      {/* Course Header */}
      <div className={`${course.banner} rounded-lg p-8 text-white`}>
        <div className="max-w-4xl">
          <p className="text-blue-200 mb-2">{course.code}</p>
          <h1 className="text-4xl font-bold mb-4">{course.title}</h1>
          <p className="text-blue-100 mb-6">Instructor: {course.instructor}</p>
          
          <div className="grid grid-cols-4 gap-4">
            <div>
              <p className="text-blue-200 text-sm">Students Enrolled</p>
              <p className="text-2xl font-bold">{course.students}</p>
            </div>
            <div>
              <p className="text-blue-200 text-sm">Modules</p>
              <p className="text-2xl font-bold">{course.modules}</p>
            </div>
            <div>
              <p className="text-blue-200 text-sm">Start Date</p>
              <p className="text-lg font-bold">{new Date(course.startDate).toLocaleDateString()}</p>
            </div>
            <div>
              <p className="text-blue-200 text-sm">End Date</p>
              <p className="text-lg font-bold">{new Date(course.endDate).toLocaleDateString()}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="card">
        <div className="flex border-b border-gray-200">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-4 font-medium border-b-2 transition ${
                activeTab === tab.id
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-700 border-transparent hover:text-gray-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h3 className="heading-3 mb-2">Course Description</h3>
                <p className="text-gray-700 leading-relaxed">{course.description}</p>
              </div>
              <div>
                <h3 className="heading-3 mb-2">Syllabus</h3>
                <p className="text-gray-700">{course.syllabus}</p>
              </div>
              <div>
                <h3 className="heading-3 mb-4">Learning Outcomes</h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-3">
                    <span className="text-blue-600 font-bold">✓</span>
                    <span className="text-gray-700">Understand Python fundamentals and syntax</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-blue-600 font-bold">✓</span>
                    <span className="text-gray-700">Write and debug Python programs</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-blue-600 font-bold">✓</span>
                    <span className="text-gray-700">Build object-oriented applications</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-blue-600 font-bold">✓</span>
                    <span className="text-gray-700">Work with libraries and packages</span>
                  </li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'content' && (
            <div className="space-y-4">
              {[1, 2, 3, 4].map(module => (
                <div key={module} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <BookOpen className="text-blue-600" />
                      <div>
                        <p className="font-semibold text-gray-900">Module {module}: Python Basics</p>
                        <p className="text-sm text-secondary">5 lessons</p>
                      </div>
                    </div>
                    <button className="btn-ghost">Open</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'assignments' && (
            <div className="space-y-4">
              {[1, 2, 3].map(assignment => (
                <div key={assignment} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <FileText className="text-purple-600" />
                      <div>
                        <p className="font-semibold text-gray-900">Assignment {assignment}: Python Problem Set</p>
                        <p className="text-sm text-secondary">Due: Due date</p>
                      </div>
                    </div>
                    <button className="btn-secondary">Submit</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'people' && (
            <div className="space-y-4">
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                    DS
                  </div>
                  <div className="flex-grow">
                    <p className="font-semibold text-gray-900">Dr. Smith</p>
                    <p className="text-sm text-secondary">Instructor</p>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 text-sm">{course.students} students enrolled</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
