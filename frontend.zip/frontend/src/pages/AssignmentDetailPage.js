import React, { useState } from 'react';
import { Upload, FileText, Send } from 'lucide-react';

export function AssignmentDetailPage() {
  const [submissionFile, setSubmissionFile] = useState(null);
  const [submissionText, setSubmissionText] = useState('');

  const assignment = {
    id: 1,
    title: 'Python Assignment 3: Data Structures',
    course: 'Introduction to Python',
    description: 'Create a program that implements and manipulates various data structures including lists, dictionaries, and sets.',
    points: 50,
    dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
    resources: ['lecture_notes.pdf', 'example_code.py'],
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="heading-1 mb-2">{assignment.title}</h1>
        <p className="text-secondary">{assignment.course}</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Description */}
          <div className="card p-6">
            <h2 className="heading-2 mb-4">Instructions</h2>
            <p className="text-gray-700 leading-relaxed">{assignment.description}</p>
          </div>

          {/* Resources */}
          {assignment.resources.length > 0 && (
            <div className="card p-6">
              <h2 className="heading-2 mb-4">Resources</h2>
              <div className="space-y-2">
                {assignment.resources.map((resource, idx) => (
                  <div key={idx} className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                    <FileText className="text-blue-600" size={20} />
                    <span className="text-gray-700">{resource}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Submission Area */}
          <div className="card p-6">
            <h2 className="heading-2 mb-4">Submit Assignment</h2>

            {/* Upload Area */}
            <div className="mb-6 border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:bg-gray-50 cursor-pointer transition">
              <Upload className="mx-auto text-gray-400 mb-3" size={32} />
              <p className="text-gray-700 font-medium mb-1">Drag and drop your file</p>
              <p className="text-sm text-secondary mb-4">or</p>
              <button className="btn-secondary">Browse Files</button>
              {submissionFile && (
                <p className="text-sm text-green-600 mt-4">✓ {submissionFile}</p>
              )}
            </div>

            {/* Text Input */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Or paste your code</label>
              <textarea
                value={submissionText}
                onChange={(e) => setSubmissionText(e.target.value)}
                placeholder="Paste your code here..."
                className="w-full h-32 p-4 border border-gray-300 rounded-lg font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Submit Button */}
            <button className="btn-primary flex items-center gap-2">
              <Send size={20} />
              Submit Assignment
            </button>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Due Date */}
          <div className="card p-6">
            <h3 className="heading-3 mb-4">Due Date</h3>
            <p className="text-2xl font-bold text-gray-900 mb-1">
              {assignment.dueDate.toLocaleDateString()}
            </p>
            <p className="text-sm text-secondary">
              {Math.ceil((assignment.dueDate - new Date()) / (1000 * 60 * 60 * 24))} days remaining
            </p>
          </div>

          {/* Points */}
          <div className="card p-6">
            <h3 className="heading-3 mb-2">Points</h3>
            <p className="text-3xl font-bold text-blue-600">{assignment.points}</p>
          </div>

          {/* Status */}
          <div className="card p-6">
            <h3 className="heading-3 mb-2">Status</h3>
            <span className="inline-block bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
              Not Submitted
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
