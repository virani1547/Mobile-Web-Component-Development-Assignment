import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, CheckSquare, BookOpen, Clock, AlertCircle } from 'lucide-react';

export function StudentDashboard({ user }) {
  const [courses, setCourses] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulated API call
    setTimeout(() => {
      setCourses([
        {
          id: 1,
          title: 'Introduction to Python',
          code: 'CS101',
          instructor: 'Dr. Smith',
          progress: 65,
          students: 45,
          image: 'bg-blue-100',
        },
        {
          id: 2,
          title: 'Web Development Basics',
          code: 'WEB201',
          instructor: 'Prof. Johnson',
          progress: 80,
          students: 32,
          image: 'bg-purple-100',
        },
        {
          id: 3,
          title: 'Data Science 101',
          code: 'DS301',
          instructor: 'Dr. Chen',
          progress: 45,
          students: 28,
          image: 'bg-green-100',
        },
      ]);

      setAssignments([
        {
          id: 1,
          title: 'Python Assignment 3',
          course: 'Introduction to Python',
          dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
          status: 'pending',
          points: 50,
        },
        {
          id: 2,
          title: 'Website Project',
          course: 'Web Development Basics',
          dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
          status: 'pending',
          points: 100,
        },
        {
          id: 3,
          title: 'Quiz: Machine Learning Basics',
          course: 'Data Science 101',
          dueDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
          status: 'overdue',
          points: 30,
        },
      ]);

      setLoading(false);
    }, 500);
  }, []);

  const getDaysUntilDue = (date) => {
    const days = Math.ceil((date - new Date()) / (1000 * 60 * 60 * 24));
    return days;
  };

  const getStatusColor = (status) => {
    return status === 'overdue' ? 'text-red-600' : 'text-blue-600';
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div>
        <h1 className="heading-1 mb-2">Welcome back, {user?.name}! 👋</h1>
        <p className="text-secondary">Here's what's happening in your courses</p>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-4">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary text-sm mb-1">Enrolled Courses</p>
              <p className="heading-3">3</p>
            </div>
            <BookOpen className="text-blue-600" size={32} />
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary text-sm mb-1">Pending Assignments</p>
              <p className="heading-3">2</p>
            </div>
            <CheckSquare className="text-yellow-600" size={32} />
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary text-sm mb-1">Grade Average</p>
              <p className="heading-3">87%</p>
            </div>
            <TrendingUp className="text-green-600" size={32} />
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary text-sm mb-1">Overdue</p>
              <p className="heading-3">1</p>
            </div>
            <AlertCircle className="text-red-600" size={32} />
          </div>
        </div>
      </div>

      {/* Upcoming Assignments */}
      <div className="card p-6">
        <h2 className="heading-2 mb-6">Upcoming Assignments</h2>
        <div className="space-y-4">
          {loading ? (
            <p className="text-secondary">Loading...</p>
          ) : assignments.length === 0 ? (
            <p className="text-secondary">No assignments</p>
          ) : (
            assignments.map(assignment => (
              <div key={assignment.id} className="border-l-4 border-blue-600 pl-4 py-2 flex items-center justify-between">
                <div className="flex-grow">
                  <h3 className="font-semibold text-gray-900">{assignment.title}</h3>
                  <p className="text-sm text-secondary">{assignment.course}</p>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-semibold ${getStatusColor(assignment.status)}`}>
                    {assignment.status === 'overdue'
                      ? 'OVERDUE'
                      : `Due in ${getDaysUntilDue(assignment.dueDate)} days`}
                  </p>
                  <p className="text-xs text-secondary">{assignment.points} points</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* My Courses */}
      <div>
        <h2 className="heading-2 mb-6">My Courses</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {loading ? (
            <p className="text-secondary">Loading...</p>
          ) : (
            courses.map(course => (
              <div key={course.id} className="card overflow-hidden hover:shadow-lg transition">
                <div className={`${course.image} h-32`} />
                <div className="p-6">
                  <p className="text-xs font-semibold text-blue-600 mb-1">{course.code}</p>
                  <h3 className="heading-3 mb-2">{course.title}</h3>
                  <p className="text-sm text-secondary mb-4">{course.instructor}</p>

                  {/* Progress Bar */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-medium text-gray-700">Progress</span>
                      <span className="text-xs font-semibold text-gray-900">{course.progress}%</span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-600 transition-all"
                        style={{ width: `${course.progress}%` }}
                      />
                    </div>
                  </div>

                  <button className="w-full btn-secondary text-center">
                    Continue Learning
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="card p-6">
        <h2 className="heading-2 mb-6">Recent Activity</h2>
        <div className="space-y-4">
          <div className="flex items-start gap-4 pb-4 border-b border-gray-200">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
              <Clock size={16} className="text-blue-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900">Assignment submitted</p>
              <p className="text-sm text-secondary">Python Assignment 2 - 2 hours ago</p>
            </div>
          </div>
          <div className="flex items-start gap-4 pb-4 border-b border-gray-200">
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
              <CheckSquare size={16} className="text-green-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900">Grade received</p>
              <p className="text-sm text-secondary">Web Development Quiz - 95/100 - 1 day ago</p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
              <BookOpen size={16} className="text-purple-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900">Course material updated</p>
              <p className="text-sm text-secondary">Data Science 101 - 3 days ago</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
