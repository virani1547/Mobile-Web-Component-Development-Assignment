import React, { useState } from 'react';
import { Search, Filter, Plus, TrendingUp } from 'lucide-react';

export function CoursesPage({ user }) {
  const [courses] = useState([
    {
      id: 1,
      title: 'Introduction to Python',
      code: 'CS101',
      instructor: 'Dr. Smith',
      progress: 65,
      students: 45,
      category: 'Programming',
      image: 'bg-blue-100',
    },
    {
      id: 2,
      title: 'Web Development Basics',
      code: 'WEB201',
      instructor: 'Prof. Johnson',
      progress: 80,
      students: 32,
      category: 'Web Development',
      image: 'bg-purple-100',
    },
    {
      id: 3,
      title: 'Data Science 101',
      code: 'DS301',
      instructor: 'Dr. Chen',
      progress: 45,
      students: 28,
      category: 'Data Science',
      image: 'bg-green-100',
    },
    {
      id: 4,
      title: 'Machine Learning Basics',
      code: 'ML401',
      instructor: 'Prof. Williams',
      progress: 0,
      students: 20,
      category: 'AI/ML',
      image: 'bg-orange-100',
    },
  ]);

  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = ['All', 'Programming', 'Web Development', 'Data Science', 'AI/ML'];

  const filteredCourses = courses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         course.code.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || course.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="heading-1 mb-2">Courses</h1>
          <p className="text-secondary">Browse and manage courses</p>
        </div>
        {user?.role === 'instructor' && (
          <button className="btn-primary flex items-center gap-2">
            <Plus size={20} />
            Create Course
          </button>
        )}
      </div>

      {/* Search and Filter */}
      <div className="card p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-grow relative">
            <Search className="absolute left-3 top-3 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search courses..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input-field pl-10"
            />
          </div>
          <button className="btn-secondary flex items-center gap-2 px-4">
            <Filter size={20} />
            Filter
          </button>
        </div>

        {/* Category Filter */}
        <div className="flex gap-2 mt-4 overflow-x-auto pb-2">
          {categories.map(category => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full whitespace-nowrap transition ${
                selectedCategory === category
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Courses Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map(course => (
          <div key={course.id} className="card overflow-hidden hover:shadow-lg transition cursor-pointer">
            <div className={`${course.image} h-32`} />
            <div className="p-6">
              <p className="text-xs font-semibold text-blue-600 mb-1">{course.code}</p>
              <h3 className="heading-3 mb-2">{course.title}</h3>
              <p className="text-sm text-secondary mb-4">{course.instructor}</p>

              {user?.role !== 'instructor' && (
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-gray-700">Progress</span>
                    <span className="text-xs font-semibold text-gray-900">{course.progress}%</span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-600 transition-all"
                      style={{ width: `${course.progress}%` }}
                    />
                  </div>
                </div>
              )}

              <button className="w-full btn-secondary text-center">
                {course.progress > 0 ? 'Continue' : 'Enroll'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
