import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  BookOpen,
  ClipboardList,
  BarChart3,
  Users,
  Calendar,
  MessageSquare,
  FileText,
  Settings,
  LogOut,
} from 'lucide-react';

export function Sidebar({ user }) {
  const location = useLocation();
  const isStudent = user?.role === 'student';
  const isInstructor = user?.role === 'instructor';

  const studentLinks = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/courses', label: 'My Courses', icon: BookOpen },
    { path: '/assignments', label: 'Assignments', icon: ClipboardList },
    { path: '/grades', label: 'Grades', icon: BarChart3 },
    { path: '/calendar', label: 'Calendar', icon: Calendar },
    { path: '/messages', label: 'Messages', icon: MessageSquare },
  ];

  const instructorLinks = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/courses', label: 'My Courses', icon: BookOpen },
    { path: '/submissions', label: 'Submissions', icon: FileText },
    { path: '/students', label: 'Students', icon: Users },
    { path: '/analytics', label: 'Analytics', icon: BarChart3 },
    { path: '/resources', label: 'Resources', icon: BookOpen },
  ];

  const links = isInstructor ? instructorLinks : studentLinks;

  const isActive = (path) => location.pathname === path;

  return (
    <aside className="w-64 bg-slate-900 text-white h-screen fixed left-0 top-16 overflow-y-auto">
      <nav className="p-4 space-y-2">
        {links.map(({ path, label, icon: Icon }) => (
          <Link
            key={path}
            to={path}
            className={`flex items-center gap-3 px-4 py-3 rounded-lg transition ${
              isActive(path)
                ? 'bg-blue-600 text-white'
                : 'text-gray-300 hover:bg-slate-800'
            }`}
          >
            <Icon size={20} />
            <span className="font-medium">{label}</span>
          </Link>
        ))}
      </nav>

      <div className="absolute bottom-4 left-4 right-4 border-t border-slate-700 pt-4 space-y-2">
        <Link
          to="/profile"
          className="flex items-center gap-3 px-4 py-2 rounded-lg text-gray-300 hover:bg-slate-800 transition"
        >
          <Settings size={20} />
          <span>Settings</span>
        </Link>
        <button className="w-full flex items-center gap-3 px-4 py-2 rounded-lg text-gray-300 hover:bg-red-900 transition">
          <LogOut size={20} />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
}
