import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Menu, X, LogOut, Settings, User, Bell } from 'lucide-react';

export function Header({ user, onLogout }) {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const isAuthenticated = !!user;
  const isLandingPage = location.pathname === '/';

  const handleLogout = () => {
    onLogout();
    navigate('/login');
  };

  return (
    <header className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 text-2xl font-bold text-blue-600">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">EL</div>
            EduLearn
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {isLandingPage && !isAuthenticated && (
              <>
                <a href="#features" className="text-gray-700 hover:text-blue-600">Features</a>
                <a href="#benefits" className="text-gray-700 hover:text-blue-600">Benefits</a>
                <a href="#testimonials" className="text-gray-700 hover:text-blue-600">Testimonials</a>
              </>
            )}
            {isAuthenticated && (
              <>
                <button className="relative p-2 text-gray-700 hover:text-blue-600">
                  <Bell size={20} />
                  <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
                </button>
              </>
            )}
          </nav>

          {/* Auth Actions */}
          <div className="hidden md:flex items-center gap-4">
            {isAuthenticated ? (
              <div className="flex items-center gap-4">
                <span className="text-gray-700">{user.name}</span>
                <button
                  onClick={() => navigate('/profile')}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <User size={20} className="text-gray-700" />
                </button>
                <button
                  onClick={handleLogout}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <LogOut size={20} className="text-gray-700" />
                </button>
              </div>
            ) : (
              <>
                <Link to="/login" className="btn-ghost">Sign In</Link>
                <Link to="/register" className="btn-primary">Get Started</Link>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden pb-4 border-t border-gray-200">
            {isLandingPage && !isAuthenticated && (
              <>
                <a href="#features" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">Features</a>
                <a href="#benefits" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">Benefits</a>
                <a href="#testimonials" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">Testimonials</a>
                <div className="px-4 py-2 border-t border-gray-200 mt-4 space-y-2">
                  <Link to="/login" className="block btn-ghost text-center">Sign In</Link>
                  <Link to="/register" className="block btn-primary text-center">Get Started</Link>
                </div>
              </>
            )}
            {isAuthenticated && (
              <div className="space-y-2">
                <button
                  onClick={() => {
                    navigate('/profile');
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left px-4 py-2 flex items-center gap-2 text-gray-700 hover:bg-gray-100"
                >
                  <User size={20} /> Profile
                </button>
                <button
                  onClick={() => {
                    navigate('/settings');
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left px-4 py-2 flex items-center gap-2 text-gray-700 hover:bg-gray-100"
                >
                  <Settings size={20} /> Settings
                </button>
                <button
                  onClick={handleLogout}
                  className="w-full text-left px-4 py-2 flex items-center gap-2 text-red-600 hover:bg-red-50"
                >
                  <LogOut size={20} /> Logout
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
}
