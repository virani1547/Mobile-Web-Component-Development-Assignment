"""
Flask REST API Routes
"""

from flask import Blueprint, request, jsonify
from models.entities import db
from services.services import (
    CourseService, AssignmentService, SubmissionService, 
    GradeService, StudentService, AuthService
)

# Create blueprints
course_bp = Blueprint('courses', __name__, url_prefix='/api/courses')
assignment_bp = Blueprint('assignments', __name__, url_prefix='/api/assignments')
submission_bp = Blueprint('submissions', __name__, url_prefix='/api/submissions')
grade_bp = Blueprint('grades', __name__, url_prefix='/api/grades')
student_bp = Blueprint('students', __name__, url_prefix='/api/students')
auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')


# Course Routes
@course_bp.route('', methods=['POST'])
def create_course():
    data = request.json
    course = CourseService.create_course(
        data['title'], data['description'], data['instructor_id'], data['capacity']
    )
    return jsonify({'id': course.id, 'title': course.title}), 201


@course_bp.route('', methods=['GET'])
def get_courses():
    courses = CourseService.get_all_courses()
    return jsonify([{
        'id': c.id, 'title': c.title, 'description': c.description,
        'instructor_id': c.instructor_id, 'capacity': c.capacity
    } for c in courses]), 200


@course_bp.route('/<course_id>', methods=['GET'])
def get_course(course_id):
    course = CourseService.get_course(course_id)
    if course:
        return jsonify({
            'id': course.id, 'title': course.title, 'description': course.description,
            'instructor_id': course.instructor_id, 'capacity': course.capacity
        }), 200
    return jsonify({'error': 'Course not found'}), 404


@course_bp.route('/<course_id>/enroll', methods=['POST'])
def enroll_student(course_id):
    data = request.json
    enrollment = CourseService.enroll_student(data['student_id'], course_id)
    return jsonify({'id': enrollment.id, 'status': enrollment.status}), 201


# Assignment Routes
@assignment_bp.route('', methods=['POST'])
def create_assignment():
    data = request.json
    from datetime import datetime
    due_date = datetime.fromisoformat(data['due_date'])
    assignment = AssignmentService.create_assignment(
        data['course_id'], data['title'], data['description'], due_date
    )
    return jsonify({'id': assignment.id, 'title': assignment.title}), 201


@assignment_bp.route('/<assignment_id>', methods=['GET'])
def get_assignment(assignment_id):
    assignment = AssignmentService.get_assignment(assignment_id)
    if assignment:
        return jsonify({
            'id': assignment.id, 'course_id': assignment.course_id, 'title': assignment.title,
            'description': assignment.description, 'due_date': assignment.due_date.isoformat()
        }), 200
    return jsonify({'error': 'Assignment not found'}), 404


@assignment_bp.route('/course/<course_id>', methods=['GET'])
def get_course_assignments(course_id):
    assignments = AssignmentService.get_course_assignments(course_id)
    return jsonify([{
        'id': a.id, 'course_id': a.course_id, 'title': a.title,
        'description': a.description, 'due_date': a.due_date.isoformat()
    } for a in assignments]), 200


# Submission Routes
@submission_bp.route('', methods=['POST'])
def submit_assignment():
    data = request.json
    submission, message = SubmissionService.submit_assignment(
        data['assignment_id'], data['student_id'], 
        data.get('file_content', ''), data.get('file_name', '')
    )
    if submission:
        return jsonify({'id': submission.id, 'status': submission.status}), 201
    return jsonify({'error': message}), 400


@submission_bp.route('/<submission_id>', methods=['GET'])
def get_submission(submission_id):
    submission = SubmissionService.get_submission(submission_id)
    if submission:
        return jsonify({
            'id': submission.id, 'assignment_id': submission.assignment_id,
            'student_id': submission.student_id, 'status': submission.status,
            'submission_timestamp': submission.submission_timestamp.isoformat()
        }), 200
    return jsonify({'error': 'Submission not found'}), 404


@submission_bp.route('/assignment/<assignment_id>', methods=['GET'])
def get_assignment_submissions(assignment_id):
    submissions = SubmissionService.get_assignment_submissions(assignment_id)
    return jsonify([{
        'id': s.id, 'student_id': s.student_id, 'status': s.status,
        'submission_timestamp': s.submission_timestamp.isoformat()
    } for s in submissions]), 200


# Grade Routes
@grade_bp.route('', methods=['POST'])
def create_grade():
    data = request.json
    grade = GradeService.grade_submission(
        data['submission_id'], data['student_id'], data['course_id'],
        data['marks'], data.get('feedback', ''), data.get('graded_by', 'system')
    )
    return jsonify({'id': grade.id, 'marks': grade.marks}), 201


@grade_bp.route('/student/<student_id>', methods=['GET'])
def get_student_grades(student_id):
    grades = GradeService.get_student_grades(student_id)
    return jsonify([{
        'id': g.id, 'marks': g.marks, 'feedback': g.feedback,
        'graded_at': g.graded_at.isoformat()
    } for g in grades]), 200


@grade_bp.route('/course/<course_id>', methods=['GET'])
def get_course_grades(course_id):
    grades = GradeService.get_course_grades(course_id)
    return jsonify([{
        'id': g.id, 'student_id': g.student_id, 'marks': g.marks,
        'feedback': g.feedback
    } for g in grades]), 200


# Student Routes
@student_bp.route('/register', methods=['POST'])
def register_student():
    data = request.json
    student = StudentService.register_student(data['name'], data['email'], data['password'])
    return jsonify({'id': student.id, 'name': student.name, 'email': student.email}), 201


@student_bp.route('/<student_id>', methods=['GET'])
def get_student(student_id):
    student = StudentService.get_student(student_id)
    if student:
        return jsonify({'id': student.id, 'name': student.name, 'email': student.email}), 200
    return jsonify({'error': 'Student not found'}), 404


@student_bp.route('', methods=['GET'])
def get_all_students():
    students = StudentService.get_all_students()
    return jsonify([{'id': s.id, 'name': s.name, 'email': s.email} for s in students]), 200


# Auth Routes
@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    # Try to authenticate as student
    student = AuthService.authenticate_student(email, password)
    if student:
        return jsonify({
            'token': f'token_{student.id}',
            'user': {
                'id': student.id,
                'name': student.name,
                'email': student.email,
                'role': 'student'
            }
        }), 200
    
    # Try to authenticate as instructor
    instructor = AuthService.authenticate_instructor(email, password)
    if instructor:
        return jsonify({
            'token': f'token_{instructor.id}',
            'user': {
                'id': instructor.id,
                'name': instructor.name,
                'email': instructor.email,
                'role': 'instructor'
            }
        }), 200
    
    return jsonify({'error': 'Invalid credentials'}), 401


@auth_bp.route('/login/student', methods=['POST'])
def login_student():
    data = request.json
    student = AuthService.authenticate_student(data['email'], data['password'])
    if student:
        return jsonify({
            'token': f'token_{student.id}',
            'user': {
                'id': student.id,
                'name': student.name,
                'email': student.email,
                'role': 'student'
            }
        }), 200
    return jsonify({'error': 'Invalid credentials'}), 401


@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    name = data.get('name')
    email = data.get('email')
    password = data.get('password')
    role = data.get('role', 'student')
    
    if role == 'instructor':
        instructor = AuthService.register_instructor(name, email, password)
        return jsonify({
            'token': f'token_{instructor.id}',
            'user': {
                'id': instructor.id,
                'name': instructor.name,
                'email': instructor.email,
                'role': 'instructor'
            }
        }), 201
    else:
        student = StudentService.register_student(name, email, password)
        return jsonify({
            'token': f'token_{student.id}',
            'user': {
                'id': student.id,
                'name': student.name,
                'email': student.email,
                'role': 'student'
            }
        }), 201


@auth_bp.route('/register/instructor', methods=['POST'])
def register_instructor():
    data = request.json
    instructor = AuthService.register_instructor(data['name'], data['email'], data['password'])
    return jsonify({
        'token': f'token_{instructor.id}',
        'user': {
            'id': instructor.id,
            'name': instructor.name,
            'email': instructor.email,
            'role': 'instructor'
        }
    }), 201
