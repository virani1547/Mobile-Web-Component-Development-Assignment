"""
Database Initialization Script
Populates EduLearn database with sample data
"""

import sys
sys.path.insert(0, '.')

from server import app, db
from models.entities import Student, Instructor, Course, Assignment, Enrollment
from datetime import datetime, timedelta
import uuid

def init_database():
    with app.app_context():
        # Clear existing data
        db.drop_all()
        db.create_all()

        # Create sample instructors
        instructor1 = Instructor(
            id=str(uuid.uuid4()),
            name='Prof. John Smith',
            email='john.smith@edulearn.com',
            password='password123',
            role='instructor'
        )
        instructor2 = Instructor(
            id=str(uuid.uuid4()),
            name='Prof. Jane Doe',
            email='jane.doe@edulearn.com',
            password='password123',
            role='instructor'
        )

        # Create sample students
        student1 = Student(
            id=str(uuid.uuid4()),
            name='Alice Johnson',
            email='alice@student.com',
            password='password123',
            role='student'
        )
        student2 = Student(
            id=str(uuid.uuid4()),
            name='Bob Williams',
            email='bob@student.com',
            password='password123',
            role='student'
        )

        # Create sample courses
        course1 = Course(
            id=str(uuid.uuid4()),
            title='Python Programming 101',
            description='Learn the basics of Python programming',
            instructor_id=instructor1.id,
            capacity=30
        )
        course2 = Course(
            id=str(uuid.uuid4()),
            title='Web Development with Flask',
            description='Build web applications using Flask',
            instructor_id=instructor2.id,
            capacity=25
        )

        # Create sample assignments
        assignment1 = Assignment(
            id=str(uuid.uuid4()),
            course_id=course1.id,
            title='Write a Hello World Program',
            description='Create your first Python program',
            due_date=datetime.utcnow() + timedelta(days=7)
        )
        assignment2 = Assignment(
            id=str(uuid.uuid4()),
            course_id=course1.id,
            title='Build a Calculator',
            description='Build a simple calculator application',
            due_date=datetime.utcnow() + timedelta(days=14)
        )

        # Create enrollments
        enrollment1 = Enrollment(
            id=str(uuid.uuid4()),
            student_id=student1.id,
            course_id=course1.id
        )
        enrollment2 = Enrollment(
            id=str(uuid.uuid4()),
            student_id=student2.id,
            course_id=course1.id
        )
        enrollment3 = Enrollment(
            id=str(uuid.uuid4()),
            student_id=student1.id,
            course_id=course2.id
        )

        # Add all to session and commit
        db.session.add_all([
            instructor1, instructor2,
            student1, student2,
            course1, course2,
            assignment1, assignment2,
            enrollment1, enrollment2, enrollment3
        ])
        db.session.commit()

        print("Database initialized successfully!")
        print(f"Created 2 instructors, 2 students, 2 courses, 2 assignments")

if __name__ == '__main__':
    init_database()
