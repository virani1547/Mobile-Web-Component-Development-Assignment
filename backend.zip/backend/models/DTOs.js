/**
 * Data Transfer Objects (DTOs)
 * Lightweight structures for API communication
 */

class StudentDTO {
  constructor(id, name, email, enrollmentStatus) {
    this.id = id;
    this.name = name;
    this.email = email;
    this.enrollmentStatus = enrollmentStatus;
  }
}

class CourseDTO {
  constructor(id, title, description, instructorId, capacity) {
    this.id = id;
    this.title = title;
    this.description = description;
    this.instructorId = instructorId;
    this.capacity = capacity;
  }
}

class AssignmentDTO {
  constructor(id, courseId, title, description, dueDate) {
    this.id = id;
    this.courseId = courseId;
    this.title = title;
    this.description = description;
    this.dueDate = dueDate;
  }
}

class SubmissionDTO {
  constructor(id, assignmentId, studentId, submissionDate, status) {
    this.id = id;
    this.assignmentId = assignmentId;
    this.studentId = studentId;
    this.submissionDate = submissionDate;
    this.status = status;
  }
}

class GradeDTO {
  constructor(id, submissionId, studentId, marks, feedback) {
    this.id = id;
    this.submissionId = submissionId;
    this.studentId = studentId;
    this.marks = marks;
    this.feedback = feedback;
  }
}

module.exports = {
  StudentDTO,
  CourseDTO,
  AssignmentDTO,
  SubmissionDTO,
  GradeDTO
};
