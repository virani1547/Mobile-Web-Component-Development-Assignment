"""
Data Transfer Objects (DTOs)
Lightweight structures for API communication
"""

class StudentDTO:
    def __init__(self, id, name, email, enrollment_status):
        self.id = id
        self.name = name
        self.email = email
        self.enrollment_status = enrollment_status
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'enrollment_status': self.enrollment_status
        }


class CourseDTO:
    def __init__(self, id, title, description, instructor_id, capacity):
        self.id = id
        self.title = title
        self.description = description
        self.instructor_id = instructor_id
        self.capacity = capacity
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'instructor_id': self.instructor_id,
            'capacity': self.capacity
        }


class AssignmentDTO:
    def __init__(self, id, course_id, title, description, due_date):
        self.id = id
        self.course_id = course_id
        self.title = title
        self.description = description
        self.due_date = due_date
    
    def to_dict(self):
        return {
            'id': self.id,
            'course_id': self.course_id,
            'title': self.title,
            'description': self.description,
            'due_date': self.due_date
        }


class SubmissionDTO:
    def __init__(self, id, assignment_id, student_id, submission_date, status):
        self.id = id
        self.assignment_id = assignment_id
        self.student_id = student_id
        self.submission_date = submission_date
        self.status = status
    
    def to_dict(self):
        return {
            'id': self.id,
            'assignment_id': self.assignment_id,
            'student_id': self.student_id,
            'submission_date': self.submission_date,
            'status': self.status
        }


class GradeDTO:
    def __init__(self, id, submission_id, student_id, marks, feedback):
        self.id = id
        self.submission_id = submission_id
        self.student_id = student_id
        self.marks = marks
        self.feedback = feedback
    
    def to_dict(self):
        return {
            'id': self.id,
            'submission_id': self.submission_id,
            'student_id': self.student_id,
            'marks': self.marks,
            'feedback': self.feedback
        }
