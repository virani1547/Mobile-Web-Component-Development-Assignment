/**
 * Entity Objects
 * Persistent domain objects mapped to database with audit fields
 */

class StudentEntity {
  constructor(id, name, email, password, role = 'student') {
    this.id = id;
    this.name = name;
    this.email = email;
    this.password = password;
    this.role = role;
    this.enrolledCourses = [];
    this.createdAt = new Date();
    this.updatedAt = new Date();
  }
}

class CourseEntity {
  constructor(id, title, description, instructorId, capacity) {
    this.id = id;
    this.title = title;
    this.description = description;
    this.instructorId = instructorId;
    this.capacity = capacity;
    this.enrolledStudents = [];
    this.assignments = [];
    this.materials = [];
    this.createdAt = new Date();
    this.updatedAt = new Date();
  }
}

class AssignmentEntity {
  constructor(id, courseId, title, description, dueDate) {
    this.id = id;
    this.courseId = courseId;
    this.title = title;
    this.description = description;
    this.dueDate = dueDate;
    this.submissions = [];
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.updatedBy = 'system';
  }
}

class SubmissionEntity {
  constructor(id, assignmentId, studentId, fileData, status = 'submitted') {
    this.id = id;
    this.assignmentId = assignmentId;
    this.studentId = studentId;
    this.fileData = fileData;
    this.status = status;
    this.submissionTimestamp = new Date();
    this.createdAt = new Date();
    this.updatedAt = new Date();
  }
}

class GradeEntity {
  constructor(id, submissionId, studentId, courseId, marks, feedback) {
    this.id = id;
    this.submissionId = submissionId;
    this.studentId = studentId;
    this.courseId = courseId;
    this.marks = marks;
    this.feedback = feedback;
    this.gradedAt = new Date();
    this.gradedBy = null;
    this.createdAt = new Date();
  }
}

class EnrollmentEntity {
  constructor(id, studentId, courseId, enrollmentDate) {
    this.id = id;
    this.studentId = studentId;
    this.courseId = courseId;
    this.enrollmentDate = enrollmentDate;
    this.status = 'active';
  }
}

class AuditLog {
  constructor(id, action, entityType, entityId, changes, userId, timestamp) {
    this.id = id;
    this.action = action;
    this.entityType = entityType;
    this.entityId = entityId;
    this.changes = changes;
    this.userId = userId;
    this.timestamp = timestamp || new Date();
  }
}

module.exports = {
  StudentEntity,
  CourseEntity,
  AssignmentEntity,
  SubmissionEntity,
  GradeEntity,
  EnrollmentEntity,
  AuditLog
};
