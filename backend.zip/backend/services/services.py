"""
Service Layer - Business Logic
"""

import uuid
from datetime import datetime
from models.entities import db, Student, Course, Assignment, Submission, Grade, Enrollment, AuditLog, Instructor
from models.dtos import StudentDTO, CourseDTO, AssignmentDTO, SubmissionDTO, GradeDTO


class CourseService:
    """Handles course creation, enrollment, and management"""
    
    @staticmethod
    def create_course(title, description, instructor_id, capacity):
        course = Course(
            id=str(uuid.uuid4()),
            title=title,
            description=description,
            instructor_id=instructor_id,
            capacity=capacity
        )
        db.session.add(course)
        db.session.commit()
        AuditLog.log_action('CREATE', 'Course', course.id, None, instructor_id)
        return course
    
    @staticmethod
    def get_course(course_id):
        return Course.query.get(course_id)
    
    @staticmethod
    def get_all_courses():
        return Course.query.all()
    
    @staticmethod
    def enroll_student(student_id, course_id):
        enrollment = Enrollment(
            id=str(uuid.uuid4()),
            student_id=student_id,
            course_id=course_id,
            status='active'
        )
        db.session.add(enrollment)
        db.session.commit()
        AuditLog.log_action('CREATE', 'Enrollment', enrollment.id, None, student_id)
        return enrollment
    
    @staticmethod
    def update_course(course_id, title=None, description=None, capacity=None):
        course = Course.query.get(course_id)
        if course:
            if title:
                course.title = title
            if description:
                course.description = description
            if capacity:
                course.capacity = capacity
            course.updated_at = datetime.utcnow()
            db.session.commit()
            AuditLog.log_action('UPDATE', 'Course', course_id, None, 'system')
        return course


class AssignmentService:
    """Handles assignment creation, scheduling, and management"""
    
    @staticmethod
    def create_assignment(course_id, title, description, due_date):
        assignment = Assignment(
            id=str(uuid.uuid4()),
            course_id=course_id,
            title=title,
            description=description,
            due_date=due_date,
            updated_by='system'
        )
        db.session.add(assignment)
        db.session.commit()
        AuditLog.log_action('CREATE', 'Assignment', assignment.id, None, 'system')
        return assignment
    
    @staticmethod
    def get_assignment(assignment_id):
        return Assignment.query.get(assignment_id)
    
    @staticmethod
    def get_course_assignments(course_id):
        return Assignment.query.filter_by(course_id=course_id).all()
    
    @staticmethod
    def update_assignment(assignment_id, title=None, description=None, due_date=None):
        assignment = Assignment.query.get(assignment_id)
        if assignment:
            if title:
                assignment.title = title
            if description:
                assignment.description = description
            if due_date:
                assignment.due_date = due_date
            assignment.updated_at = datetime.utcnow()
            db.session.commit()
            AuditLog.log_action('UPDATE', 'Assignment', assignment_id, None, 'system')
        return assignment


class SubmissionService:
    """Handles assignment submissions and validation"""
    
    @staticmethod
    def submit_assignment(assignment_id, student_id, file_content, file_name):
        assignment = Assignment.query.get(assignment_id)
        
        # Check deadline
        if datetime.utcnow() > assignment.due_date:
            return None, "Deadline expired"
        
        submission = Submission(
            id=str(uuid.uuid4()),
            assignment_id=assignment_id,
            student_id=student_id,
            file_content=file_content,
            file_name=file_name,
            status='submitted'
        )
        db.session.add(submission)
        db.session.commit()
        AuditLog.log_action('CREATE', 'Submission', submission.id, None, student_id)
        return submission, "Submission successful"
    
    @staticmethod
    def get_submission(submission_id):
        return Submission.query.get(submission_id)
    
    @staticmethod
    def get_assignment_submissions(assignment_id):
        return Submission.query.filter_by(assignment_id=assignment_id).all()
    
    @staticmethod
    def update_submission_status(submission_id, status):
        submission = Submission.query.get(submission_id)
        if submission:
            submission.status = status
            submission.updated_at = datetime.utcnow()
            db.session.commit()
            AuditLog.log_action('UPDATE', 'Submission', submission_id, None, 'system')
        return submission


class GradeService:
    """Handles grading and feedback"""
    
    @staticmethod
    def grade_submission(submission_id, student_id, course_id, marks, feedback, graded_by):
        grade = Grade(
            id=str(uuid.uuid4()),
            submission_id=submission_id,
            student_id=student_id,
            course_id=course_id,
            marks=marks,
            feedback=feedback,
            graded_by=graded_by
        )
        db.session.add(grade)
        db.session.commit()
        AuditLog.log_action('CREATE', 'Grade', grade.id, None, graded_by)
        return grade
    
    @staticmethod
    def get_student_grades(student_id):
        return Grade.query.filter_by(student_id=student_id).all()
    
    @staticmethod
    def get_course_grades(course_id):
        return Grade.query.filter_by(course_id=course_id).all()
    
    @staticmethod
    def update_grade(grade_id, marks=None, feedback=None):
        grade = Grade.query.get(grade_id)
        if grade:
            if marks is not None:
                grade.marks = marks
            if feedback:
                grade.feedback = feedback
            db.session.commit()
            AuditLog.log_action('UPDATE', 'Grade', grade_id, None, 'system')
        return grade


class StudentService:
    """Handles student registration and management"""
    
    @staticmethod
    def register_student(name, email, password):
        student = Student(
            id=str(uuid.uuid4()),
            name=name,
            email=email,
            password=password,
            role='student'
        )
        db.session.add(student)
        db.session.commit()
        AuditLog.log_action('CREATE', 'Student', student.id, None, student.id)
        return student
    
    @staticmethod
    def get_student(student_id):
        return Student.query.get(student_id)
    
    @staticmethod
    def get_student_by_email(email):
        return Student.query.filter_by(email=email).first()
    
    @staticmethod
    def get_all_students():
        return Student.query.all()
    
    @staticmethod
    def get_student_enrollments(student_id):
        return Enrollment.query.filter_by(student_id=student_id).all()


class AuthService:
    """Handles authentication and authorization"""
    
    @staticmethod
    def authenticate_student(email, password):
        student = Student.query.filter_by(email=email).first()
        if student and student.password == password:
            return student
        return None
    
    @staticmethod
    def authenticate_instructor(email, password):
        instructor = Instructor.query.filter_by(email=email).first()
        if instructor and instructor.password == password:
            return instructor
        return None
    
    @staticmethod
    def register_instructor(name, email, password):
        instructor = Instructor(
            id=str(uuid.uuid4()),
            name=name,
            email=email,
            password=password,
            role='instructor'
        )
        db.session.add(instructor)
        db.session.commit()
        return instructor


# Extend AuditLog with logging method
AuditLog.log_action = staticmethod(lambda action, entity_type, entity_id, changes, user_id: (
    db.session.add(AuditLog(
        id=str(uuid.uuid4()),
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        changes=changes,
        user_id=user_id
    )),
    db.session.commit()
))
