"""
EduLearn LMS Backend Server
Flask application with SQL database
"""

import os
from flask import Flask, send_from_directory, send_file
from flask_cors import CORS
from models.entities import db
from routes.api import course_bp, assignment_bp, submission_bp, grade_bp, student_bp, auth_bp

app = Flask(__name__, instance_path=os.path.join(os.path.dirname(__file__), 'instance'))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///edulearn.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database
db.init_app(app)

# Enable CORS
CORS(app)

# Set up frontend directory path
frontend_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'frontend')

# Serve static files from frontend directory
@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory(os.path.join(frontend_dir), filename)

# Serve the main index.html for root
@app.route('/')
def serve_index():
    return send_file(os.path.join(frontend_dir, 'index.html'))

# Serve HTML files directly
@app.route('/<filename>')
def serve_html(filename):
    if filename.endswith('.html') or filename.endswith('.js') or filename.endswith('.css'):
        try:
            return send_file(os.path.join(frontend_dir, filename))
        except:
            return send_file(os.path.join(frontend_dir, 'index.html'))
    if filename.startswith('api/'):
        return {'error': 'Not found'}, 404
    return send_file(os.path.join(frontend_dir, 'index.html'))

# Register blueprints
app.register_blueprint(course_bp)
app.register_blueprint(assignment_bp)
app.register_blueprint(submission_bp)
app.register_blueprint(grade_bp)
app.register_blueprint(student_bp)
app.register_blueprint(auth_bp)

@app.route('/api/health', methods=['GET'])
def health():
    return {'status': 'EduLearn API is running'}, 200

@app.route('/api/routes', methods=['GET'])
def list_routes():
    """List all registered API routes"""
    output = []
    for rule in app.url_map.iter_rules():
        methods = ','.join(sorted(rule.methods - {'HEAD', 'OPTIONS'}))
        output.append({
            'endpoint': rule.endpoint,
            'methods': methods,
            'route': str(rule)
        })
    return {'routes': sorted(output, key=lambda x: x['route'])}, 200

# Create database tables
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
